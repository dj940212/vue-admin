particlesJS.load('particles-js', 'static/js/particles.json', function() {
  console.log('callback - particles.js config loaded');
});
console.log(particlesJS)
